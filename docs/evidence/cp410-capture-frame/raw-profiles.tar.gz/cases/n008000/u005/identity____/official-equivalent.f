unused000 := 0
unused001 := 1
unused002 := 2
unused003 := 3
unused004 := 4
a := []
i := 1
while(i <= 8000) { a.push(8000-i+1); i += 1 }
a = a.sort_by(x => x)
print(a[0]); print(a[8000-1])
