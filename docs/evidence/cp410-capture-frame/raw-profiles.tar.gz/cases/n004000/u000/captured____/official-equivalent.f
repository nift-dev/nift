offset := 1
a := []
i := 1
while(i <= 4000) { a.push(4000-i+1); i += 1 }
a = a.sort_by(x => x+offset)
print(a[0]); print(a[4000-1])
