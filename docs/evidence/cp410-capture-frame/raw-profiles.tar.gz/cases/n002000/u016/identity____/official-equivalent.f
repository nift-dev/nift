unused000 := 0
unused001 := 1
unused002 := 2
unused003 := 3
unused004 := 4
unused005 := 5
unused006 := 6
unused007 := 7
unused008 := 8
unused009 := 9
unused010 := 10
unused011 := 11
unused012 := 12
unused013 := 13
unused014 := 14
unused015 := 15
a := []
i := 1
while(i <= 2000) { a.push(2000-i+1); i += 1 }
a = a.sort_by(x => x)
print(a[0]); print(a[2000-1])
