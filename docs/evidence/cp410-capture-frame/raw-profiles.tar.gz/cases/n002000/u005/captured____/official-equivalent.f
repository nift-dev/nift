unused000 := 0
unused001 := 1
unused002 := 2
unused003 := 3
unused004 := 4
offset := 1
a := []
i := 1
while(i <= 2000) { a.push(2000-i+1); i += 1 }
a = a.sort_by(x => x+offset)
print(a[0]); print(a[2000-1])
