#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>
#include <valgrind/callgrind.h>
struct Binding {std::shared_ptr<std::shared_ptr<double>> slot;};
using Env=std::unordered_map<std::string,Binding>;
struct Instance {std::size_t id;std::shared_ptr<const Env> environment;};
struct Key {double key;std::size_t index;};
int main(int argc,char**argv){
 if(argc!=4)return 2;
 std::string mode=argv[1];std::size_t n=std::strtoull(argv[2],nullptr,10),unused=std::strtoull(argv[3],nullptr,10);
 std::vector<double> input;input.reserve(n);for(std::size_t i=0;i<n;++i)input.push_back(double(n-i));
 auto env=std::make_shared<Env>();for(std::size_t i=0;i<unused+4;++i)env->emplace("binding"+std::to_string(i),Binding{std::make_shared<std::shared_ptr<double>>(std::make_shared<double>(double(i)))});
 std::vector<Instance> registry;registry.reserve(n);std::vector<Key> keys;keys.reserve(n);
 CALLGRIND_ZERO_STATS;CALLGRIND_TOGGLE_COLLECT;
 for(std::size_t i=0;i<n;++i){
  if(mode=="retained-shared")registry.push_back({i+1,env});
  else if(mode=="retained-copy")registry.push_back({i+1,std::make_shared<Env>(*env)});
  else if(mode!="key-floor")return 2;
  // Identity selector: exactly one key evaluation per element.
  keys.push_back({input[i],i});
 }
 std::stable_sort(keys.begin(),keys.end(),[](const Key&a,const Key&b){return a.key<b.key;});
 std::vector<double> output;output.reserve(n);for(const auto& key:keys)output.push_back(input[key.index]);
 std::cout<<output.front()<<'\n'<<output.back()<<'\n';
 // Retention through operation completion, including deterministic teardown.
 registry.clear();keys.clear();output.clear();CALLGRIND_TOGGLE_COLLECT;
}
