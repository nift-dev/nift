#include <filesystem>
#include <iostream>
#include <vector>
#include <algorithm>
#include <memory>
namespace fs=std::filesystem;
struct Match {fs::path absolute;std::shared_ptr<const fs::path> canonical_parent;};
void walk(const fs::path& p,std::vector<Match>& out){
 std::error_code base_error;auto canonical_parent=std::make_shared<const fs::path>(fs::weakly_canonical(p,base_error));
 std::error_code ec;
 for(fs::directory_iterator i(p,fs::directory_options::skip_permission_denied,ec),end;!ec&&i!=end;i.increment(ec)){
  const auto&e=*i;auto filename=e.path().filename();auto name=filename.string();if(!name.empty()&&name[0]=='.')continue;
  std::error_code exists_error;
  if(name.size()>=4&&name.substr(name.size()-4)==".dat"&&fs::exists(e.path(),exists_error)&&!exists_error){
   std::error_code link_error;bool link=e.is_symlink(link_error);
   out.push_back({fs::absolute(e.path()).lexically_normal(),(!base_error&&!link_error&&!link)?canonical_parent:std::shared_ptr<const fs::path>{}});
  }
  std::error_code directory_error,symlink_error;
  if(e.is_directory(directory_error)&&!directory_error&&!e.is_symlink(symlink_error)&&!symlink_error)walk(e.path(),out);
 }
}
int main(int argc,char**){
 std::vector<Match> out;walk(fs::absolute("files"),out);std::vector<std::pair<std::string,Match>> keyed;keyed.reserve(out.size());for(auto&x:out)keyed.emplace_back(x.absolute.generic_string(),std::move(x));
 std::sort(keyed.begin(),keyed.end(),[](const auto&a,const auto&b){return a.first<b.first;});for(std::size_t i=0;i<out.size();++i)out[i]=std::move(keyed[i].second);
 out.erase(std::unique(out.begin(),out.end(),[](const auto&a,const auto&b){return a.absolute==b.absolute;}),out.end());
 std::error_code base_error;auto base=fs::weakly_canonical(fs::current_path(),base_error);std::vector<std::string> shown;shown.reserve(out.size());
 for(const auto&m:out){std::error_code ec;auto canonical=m.canonical_parent?*m.canonical_parent/m.absolute.filename():fs::weakly_canonical(m.absolute,ec);auto relative=canonical.lexically_relative(base);shown.push_back((ec||base_error?m.absolute:relative).generic_string());}
 if(argc>1)for(const auto&s:shown)std::cout<<s<<'\n';else std::cout<<shown.size()<<'\n';
}
