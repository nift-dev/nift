from pathlib import Path
import subprocess,json,re
p=Path(__file__).parent.resolve();rows=[]
for width in [8,32,128,512,2000,8000]:
 for op in ['reads','writes','iteration','mutation','copy-move']:
  expected=None
  for mode in ['vector','lazy','hybrid','operation-local']:
   cg=p/f'{width}-{op}-{mode}.callgrind';r=subprocess.run(['valgrind','--tool=callgrind','--collect-atstart=no','--callgrind-out-file='+str(cg),str(p/'probe'),mode,str(width),op],text=True,capture_output=True,check=True)
   if expected is None:expected=r.stdout
   assert r.stdout==expected,(width,op,mode,r.stdout,expected)
   rows.append(dict(width=width,operation=op,model=mode,instructions=int(re.search(r'^summary: (\d+)',cg.read_text(),re.M)[1]),stdout=r.stdout,scope='isolated actual RuntimeValue ordered storage plus scratch membership index; excludes public-API mutation interception'))
  print(width,op,'PASS',flush=True);(p/'instructions.json').write_text(json.dumps(rows,indent=2)+'\n')
