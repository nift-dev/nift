#include "RuntimeValue.h"
#include <valgrind/callgrind.h>
#include <cstdlib>
#include <iostream>
#include <memory>
#include <unordered_map>
using Index=std::unordered_map<std::string,std::size_t>;
struct Object {
 nift::RuntimeValue value=nift::RuntimeValue::make_object();std::unique_ptr<Index> index;
 Object()=default;Object(const Object& other):value(other.value){};Object(Object&&)=default;
 void build(){if(index)return;index=std::make_unique<Index>();index->reserve(value.object.size());for(std::size_t i=0;i<value.object.size();++i)index->try_emplace(value.object[i].first,i);}
 nift::RuntimeValue* find(const std::string& key,std::size_t threshold){if(threshold&&value.object.size()>=threshold){build();auto i=index->find(key);return i==index->end()?nullptr:&value.object[i->second].second;}return value.find_member(key);}
 void append(std::string key,double x){auto i=value.object.size();value.object.emplace_back(std::move(key),nift::RuntimeValue(x));if(index)index->try_emplace(value.object.back().first,i);}
 void erase(const std::string& key,std::size_t threshold){auto* v=find(key,threshold);if(!v)return;std::size_t pos=0;for(;pos<value.object.size();++pos)if(value.object[pos].first==key)break;
  value.object.erase(value.object.begin()+pos);if(index){index->erase(key);for(auto& kv:*index)if(kv.second>pos)--kv.second;}}
};
int main(int argc,char**argv){if(argc!=4)return 2;std::string mode=argv[1],op=argv[3];std::size_t width=std::strtoull(argv[2],nullptr,10);std::size_t threshold=mode=="vector"?0:mode=="lazy"?1:mode=="hybrid"?128:32;
 Object object;for(std::size_t i=0;i<width;++i)object.append("key-"+std::to_string(i),double(i));std::vector<std::string> names;for(std::size_t i=0;i<4096;++i)names.push_back("key-"+std::to_string((i*7919)%width));double sum=0;
 CALLGRIND_ZERO_STATS;CALLGRIND_TOGGLE_COLLECT;
 if(op=="reads"||op=="writes"){for(std::size_t i=0;i<names.size();++i){auto* v=object.find(names[i],threshold);if(!v)return 3;if(op=="writes")v->num=double(i);sum+=v->num;}}
 else if(op=="iteration"){for(int i=0;i<32;++i)for(const auto&kv:object.value.object)sum+=kv.second.num;}
 else if(op=="mutation"){for(int i=0;i<32;++i){std::string key="added-"+std::to_string(i);object.append(key,i);auto*v=object.find(key,threshold);if(!v)return 3;sum+=v->num;object.erase(key,threshold);}}
 else if(op=="copy-move"){for(int i=0;i<16;++i){Object copy(object);Object moved(std::move(copy));auto*v=moved.find(names[i],threshold);if(!v)return 3;sum+=v->num;}}
 else return 2;
 if(mode=="operation-local")object.index.reset();
 CALLGRIND_TOGGLE_COLLECT;std::cout<<sum<<'\n';}
