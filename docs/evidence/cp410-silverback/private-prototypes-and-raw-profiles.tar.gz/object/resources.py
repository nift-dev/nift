from pathlib import Path
import subprocess,json,re
p=Path(__file__).parent.resolve();rows=[]
for width in [8,32,128,512,2000,8000]:
 for op in ['reads','writes','iteration','mutation','copy-move']:
  expected=None
  for mode in ['vector','lazy','hybrid','operation-local']:
   r=subprocess.run(['/usr/bin/time','-f','rss_kib=%M',str(p/'alloc-probe'),mode,str(width),op],capture_output=True,text=True,check=True)
   if expected is None:expected=r.stdout
   assert r.stdout==expected
   m=re.search(r'parse allocations=(\d+) bytes=(\d+) peak_payload=(\d+)',r.stderr);assert m,r.stderr
   row=dict(width=width,operation=op,model=mode,allocations=int(m[1]),bytes=int(m[2]),peak_payload_bytes=int(m[3]),rss_kib=int(re.search(r'rss_kib=(\d+)',r.stderr)[1]),scope='ordinary allocator counters for isolated operation; RSS whole short process includes fixture/runtime and is descriptive, not an acceptance timing')
   log=p/f'{width}-{op}-{mode}.memcheck';r=subprocess.run(['valgrind','--tool=memcheck','--leak-check=full','--error-exitcode=99','--log-file='+str(log),str(p/'probe'),mode,str(width),op],capture_output=True,text=True,check=True);assert r.stdout==expected;s=log.read_text();assert 'ERROR SUMMARY: 0 errors' in s and 'in use at exit: 0 bytes in 0 blocks' in s
   row['memcheck_errors']=0;rows.append(row)
   (p/'resources.json').write_text(json.dumps(rows,indent=2)+'\n')
  print(width,op,'PASS',flush=True)
