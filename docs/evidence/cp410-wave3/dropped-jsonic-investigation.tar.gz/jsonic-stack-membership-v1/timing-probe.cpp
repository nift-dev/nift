#include JSONIC_HEADER
#include <fstream>
#include <iterator>
#include <iostream>
#include <cstdlib>
#include <ctime>
int main(int argc,char**argv){if(argc!=3)return 2;std::ifstream in(argv[1]);std::string text((std::istreambuf_iterator<char>(in)),{});unsigned n=std::strtoul(argv[2],nullptr,10);json::ParseOptions options;options.duplicate_keys=json::DuplicateKeyPolicy::Reject;std::size_t checksum=0;timespec start{},end{};clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&start);for(unsigned i=0;i<n;++i){json::Document value;json::ParseDiagnostic d;bool ok=json::Document::parse(text,value,d,options);checksum+=ok?value.object.size():d.offset;}clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&end);std::cout<<checksum<<'\t'<<double(end.tv_sec-start.tv_sec)+double(end.tv_nsec-start.tv_nsec)/1e9<<'\n';}
