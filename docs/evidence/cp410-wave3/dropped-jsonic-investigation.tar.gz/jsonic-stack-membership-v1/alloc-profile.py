from pathlib import Path
import subprocess,json,re
p=Path(__file__).parent.resolve();old=Path('.build/cp410-capture-frame/jsonic').resolve();rows=[]
for label in ['baseline','candidate']:
 subprocess.run(['g++','-std=c++17','-O2','-Wall','-Wextra','-Werror','-I'+str(old),str(p/(label+'.cpp')),str(old/'Alloc.cpp'),'-o',str(p/(label+'-alloc'))],check=True)
for width in (8,16,32,64,128,256,512,1000,2000,4000,8000):
 for kind in ('unique','early','middle','end','escaped'):
  expected=None
  for label in ['baseline','candidate']:
   log=p/f'{width}-{kind}-{label}.memcheck';r=subprocess.run(['valgrind','--tool=memcheck','--leak-check=full','--error-exitcode=99','--log-file='+str(log),str(p/(label+'-alloc')),str(old/f'{kind}-{width}.json'),'reject'],capture_output=True,text=True,check=True)
   if expected is None:expected=r.stdout
   assert r.stdout==expected;s=log.read_text();assert 'ERROR SUMMARY: 0 errors' in s and 'in use at exit: 0 bytes in 0 blocks' in s
   m=re.search(r'parse allocations=(\d+) bytes=(\d+) peak_payload=(\d+)',r.stderr);assert m
   rows.append(dict(width=width,kind=kind,label=label,allocations=int(m[1]),bytes=int(m[2]),peak_payload_bytes=int(m[3]),memcheck_errors=0))
  (p/'allocations.json').write_text(json.dumps(rows,indent=2)+'\n');print(width,kind,'PASS',flush=True)
