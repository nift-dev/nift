from pathlib import Path
import subprocess,json,statistics
p=Path(__file__).parent.resolve();fixtures=Path('.build/cp410-capture-frame/jsonic').resolve();rows=[]
for w in [8,16,32,64,128]:
 for rep in range(8):
  for label in (['baseline','candidate'] if rep%2==0 else ['candidate','baseline']):
   r=subprocess.run([str(p/(label+'-timing')),str(fixtures/f'unique-{w}.json'),'500000'],capture_output=True,text=True,check=True)
   check,cpu=r.stdout.split();assert int(check)==w*500000
   rows.append(dict(width=w,label=label,repeat=rep,iterations=500000,cpu=float(cpu)))
  print(w,rep,flush=True)
  (p/'long-timing.json').write_text(json.dumps(rows,indent=2)+'\n')
summary=[]
for w in [8,16,32,64,128]:
 a=statistics.median(r['cpu'] for r in rows if r['width']==w and r['label']=='baseline');b=statistics.median(r['cpu'] for r in rows if r['width']==w and r['label']=='candidate');summary.append(dict(width=w,baseline_cpu=a,candidate_cpu=b,change_percent=100*(b/a-1)))
(p/'long-timing-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(summary)
