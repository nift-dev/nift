from pathlib import Path
import subprocess,json,re
p=Path(__file__).parent.resolve();old=Path('.build/cp410-capture-frame/jsonic').resolve();rows=[]
probe=(old/'probe.cpp').read_text()
for label,header in [('baseline',p/'baseline-json.h'),('candidate',Path('/home/nick/Repositories/nift/jsonic/jsonic/include/json.h'))]:
 (p/(label+'.cpp')).write_text(probe.replace('#include "json.h"','#include "'+str(header)+'"'))
 subprocess.run(['g++','-std=c++17','-O2','-Wall','-Wextra','-Werror','-I'+str(old),str(p/(label+'.cpp')),'-o',str(p/label)],check=True)
for n in (8,16,32,64,128,256,512,1000,2000,4000,8000):
 for kind in ('unique','early','middle','end','escaped'):
  expected=None
  for label in ('baseline','candidate'):
   cg=p/f'{n}-{kind}-{label}.callgrind';r=subprocess.run(['valgrind','--tool=callgrind','--collect-atstart=no','--callgrind-out-file='+str(cg),str(p/label),str(old/f'{kind}-{n}.json'),'reject'],capture_output=True,text=True,check=True)
   if expected is None:expected=r.stdout
   assert r.stdout==expected
   rows.append({'width':n,'kind':kind,'label':label,'instructions':int(re.search(r'^summary: (\d+)',cg.read_text(),re.M)[1]),'stdout':expected})
  print(n,kind,'PASS',flush=True);(p/'instructions.json').write_text(json.dumps(rows,indent=2)+'\n')
