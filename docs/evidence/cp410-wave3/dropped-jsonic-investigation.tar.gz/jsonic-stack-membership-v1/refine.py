from pathlib import Path
import json,subprocess,re,shutil,time
p=Path(__file__).parent.resolve();old=Path('.build/cp410-capture-frame/jsonic').resolve()
while not (p/'long-timing-summary.json').exists():time.sleep(1)
archive=p.parent/'jsonic-stack-membership-v1';shutil.copytree(p,archive,dirs_exist_ok=True)
# Reuse the immutable baseline and reproduce the canonical candidate only.
subprocess.run(['g++','-std=c++17','-O2','-Wall','-Wextra','-Werror','-I'+str(old),str(p/'candidate.cpp'),'-o',str(p/'candidate')],check=True)
subprocess.run(['g++','-std=c++17','-O2','-Wall','-Wextra','-Werror','-DJSONIC_HEADER="/home/nick/Repositories/nift/jsonic/jsonic/include/json.h"',str(p/'timing-probe.cpp'),'-o',str(p/'candidate-timing')],check=True)
rows=[]
for w in [8,16,32,64,128]:
 for rep in range(8):
  for label in (['baseline','candidate'] if rep%2==0 else ['candidate','baseline']):
   r=subprocess.run([str(p/(label+'-timing')),str(old/f'unique-{w}.json'),'100000'],capture_output=True,text=True,check=True);check,cpu=r.stdout.split();assert int(check)==w*100000
   rows.append(dict(width=w,label=label,repeat=rep,iterations=100000,cpu=float(cpu)))
  print('optional CPU',w,rep,flush=True);(p/'optional-long-timing.json').write_text(json.dumps(rows,indent=2)+'\n')
base=json.loads((archive/'instructions.json').read_text());rows=[r for r in base if r['label']=='baseline']
for w in [8,16,32,64,128,256,512,1000,2000,4000,8000]:
 for kind in ['unique','early','middle','end','escaped']:
  cg=p/f'{w}-{kind}-candidate.callgrind';r=subprocess.run(['valgrind','--tool=callgrind','--collect-atstart=no','--callgrind-out-file='+str(cg),str(p/'candidate'),str(old/f'{kind}-{w}.json'),'reject'],capture_output=True,text=True,check=True)
  baseline=next(x for x in base if x['width']==w and x['kind']==kind and x['label']=='baseline');assert r.stdout==baseline['stdout']
  rows.append(dict(width=w,kind=kind,label='candidate',instructions=int(re.search(r'^summary: (\d+)',cg.read_text(),re.M)[1]),stdout=r.stdout));(p/'instructions.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('optional CG',w,'PASS',flush=True)
print('COMPLETE optional refinement',flush=True)
