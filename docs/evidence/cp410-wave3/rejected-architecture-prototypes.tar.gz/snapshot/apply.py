from pathlib import Path
p=Path(__file__).parent
h=p/'src/Parser.h';s=h.read_text();mark='    static void copy_capture_bindings(';s=s.replace(mark,(p/'BindingScope.inc').read_text()+mark,1);s=s.replace('std::vector<std::unordered_map<std::string, VariableBinding>>','std::vector<BindingScope>');s=s.replace('        std::unordered_map<std::string, VariableBinding> captures;','        BindingScope captures;');h.write_text(s)
pf=p/'src/Parser.cpp';s=pf.read_text();mark='void Parser::copy_capture_bindings('
impl='''std::shared_ptr<const Parser::BindingMap> Parser::capture_snapshot() {
    auto previous = last_capture_snapshot_.lock();
    if (previous) {
        std::size_t names = 0;
        for (const auto& scope : variable_scopes_) names += scope.size();
        bool equal = names == previous->size();
        auto owner_equal = [](const auto& a, const auto& b) {
            return a.get() == b.get() && !a.owner_before(b) && !b.owner_before(a);
        };
        for (std::size_t i = 0; equal && i < variable_scopes_.size(); ++i) {
            for (const auto& kv : variable_scopes_[i]) {
                // Equal raw cardinality alone cannot rule out shadowed duplicates.
                for (std::size_t j = i + 1; j < variable_scopes_.size(); ++j)
                    if (variable_scopes_[j].count(kv.first)) { equal = false; break; }
                if (!equal) break;
                auto found = previous->find(kv.first);
                if (found == previous->end()) { equal = false; break; }
                const auto& a = kv.second; const auto& b = found->second;
                if (!owner_equal(a.value,b.value) || !owner_equal(a.slot,b.slot) ||
                    !owner_equal(a.ref_root_slot,b.ref_root_slot) || a.type != b.type ||
                    a.mutable_binding != b.mutable_binding || a.deep_readonly != b.deep_readonly ||
                    a.is_script_invocation != b.is_script_invocation || a.ref_valid != b.ref_valid ||
                    a.ref_path != b.ref_path) { equal = false; break; }
            }
        }
        if (equal) return previous;
    }
    auto fresh = std::make_shared<BindingMap>();
    for (const auto& scope : variable_scopes_) copy_capture_bindings(*fresh,scope);
    return fresh;
}

''';s=s.replace(mark,impl+mark,1);pf.write_text(s)
e=p/'src/ParserExpression.cpp';s=e.read_text();s=s.replace('for(const auto& scope:variable_scopes_) copy_capture_bindings(li->captures,scope);','li->captures=BindingScope(capture_snapshot());');s=s.replace('lambda_instances_[id]=li;','lambda_instances_[id]=li; last_capture_snapshot_=li->captures.snapshot();');s=s.replace('copy_capture_bindings(sc,fn->captures);','sc=fn->captures;');e.write_text(s)
