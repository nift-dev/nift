unused0 := 0
unused1 := 1
unused2 := 2
unused3 := 3
unused4 := 4
unused5 := 5
unused6 := 6
unused7 := 7
unused8 := 8
unused9 := 9
unused10 := 10
unused11 := 11
unused12 := 12
unused13 := 13
unused14 := 14
unused15 := 15
a := []
i := 1
while(i <= 8000) { a.push(8000-i+1); i += 1 }
a = a.sort_by(x => x)
print(a[0]); print(a[8000-1]); print(a[4000-1])
