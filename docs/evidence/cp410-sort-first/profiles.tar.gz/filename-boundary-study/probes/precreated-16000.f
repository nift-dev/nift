a := []
i := 1
while(i <= 16000) { a.push(16000-i+1); i += 1 }
f := x => x
a = a.sort_by(f)
print(a[0]); print(a[16000-1]); print(a[8000-1])
