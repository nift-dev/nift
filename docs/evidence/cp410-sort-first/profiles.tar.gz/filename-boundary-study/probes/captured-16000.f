offset := 1
a := []
i := 1
while(i <= 16000) { a.push(16000-i+1); i += 1 }
a = a.sort_by(x => x+offset)
print(a[0]); print(a[16000-1]); print(a[8000-1])
