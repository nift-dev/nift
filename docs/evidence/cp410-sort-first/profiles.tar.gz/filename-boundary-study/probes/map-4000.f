a := []
i := 1
while(i <= 4000) { a.push(4000-i+1); i += 1 }
a = a.map(x => x)
print(a[0]); print(a[4000-1]); print(a[2000-1])
