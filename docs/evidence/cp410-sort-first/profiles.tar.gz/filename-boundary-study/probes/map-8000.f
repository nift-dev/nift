a := []
i := 1
while(i <= 8000) { a.push(8000-i+1); i += 1 }
a = a.map(x => x)
print(a[0]); print(a[8000-1]); print(a[4000-1])
