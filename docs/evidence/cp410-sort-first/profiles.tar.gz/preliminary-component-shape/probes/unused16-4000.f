unused0 := 0
unused1 := 1
unused2 := 2
unused3 := 3
unused4 := 4
unused5 := 5
unused6 := 6
unused7 := 7
unused8 := 8
unused9 := 9
unused10 := 10
unused11 := 11
unused12 := 12
unused13 := 13
unused14 := 14
unused15 := 15
a := []
i := 1
while(i <= 4000) { a.push(4000-i+1); i += 1 }
b := a.sort_by(x => x)
print(b.size())
