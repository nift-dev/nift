f := x => x
a := []
i := 1
while(i <= 16000) { a.push(16000-i+1); i += 1 }
b := a.sort_by(f)
print(b.size())
