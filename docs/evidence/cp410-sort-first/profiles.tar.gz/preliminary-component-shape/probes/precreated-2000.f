f := x => x
a := []
i := 1
while(i <= 2000) { a.push(2000-i+1); i += 1 }
b := a.sort_by(f)
print(b.size())
