a := []
i := 1
while(i <= 2000) { a.push(2000-i+1); i += 1 }
b := a.map(x => x)
print(b.size())
