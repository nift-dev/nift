a := []
i := 1
while(i <= 8000) { a.push(8000-i+1); i += 1 }
b := a.map(x => x)
print(b.size())
