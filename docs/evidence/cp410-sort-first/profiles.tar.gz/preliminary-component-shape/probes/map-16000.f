a := []
i := 1
while(i <= 16000) { a.push(16000-i+1); i += 1 }
b := a.map(x => x)
print(b.size())
